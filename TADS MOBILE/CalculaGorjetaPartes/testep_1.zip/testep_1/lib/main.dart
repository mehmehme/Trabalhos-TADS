import 'package:flutter/material.dart';

void main() {
  runApp(HomeMat());
}

class HomeMat extends StatelessWidget {
  const HomeMat({super.key});
/*define qual pagina e a principal*/
  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      home: ScHome(),
    );
  }
}

class ScHome extends StatelessWidget {
  const ScHome({super.key});
/*cria o widget da app bar, ou a pagina 1*/
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: const Text(
          "Calculadora Gorjeta",
          style: TextStyle(
              color: Colors.black,
              fontWeight: FontWeight.bold
          ),
        ),
          backgroundColor: Color.fromRGBO(181, 134, 63,0.2),
        ),
            backgroundColor:Color.fromRGBO(252, 228, 149,0.5) ,
          body: HomeBody(),
    );
  }
}
/*widget*/
class HomeBody extends StatefulWidget {
  const HomeBody({super.key});

  @override
  State<HomeBody> createState() => _HomeBodyState();
}
/*estado*/
class _HomeBodyState extends State<HomeBody> {
/*cria var que vai inicializar dps*/
  late double _resultado;
  late TextEditingController _controller;
/*inicia os estados*/
  @override
  void initState() {
    _resultado = 0;
    _controller = TextEditingController();
    super.initState();
  }
/*calcula gorjeta*/
  void calcula(){
    setState((){
      _resultado = double.parse(_controller.value.text)*1.1;
    });
  }
/*evita vazamento de memoria*/
  @override
  void dispose(){
    super.dispose();
    _controller.dispose();
  }
/*o texto, imagem e botao do app*/
  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Container(
          width: 150,
          height: 150,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            border: Border.all(
              width: 8,
              color: Color.fromRGBO(181, 134, 63,1),
            ),
            image: DecorationImage(
                image: AssetImage("images/gorjeta.png"),
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.all(20.0),
          child: TextField(
            controller: _controller,
            keyboardType: TextInputType.number,
            onChanged: (value) => calcula(),
            decoration: InputDecoration(
              hintText: "Quanto deu sua compra hoje?",
              fillColor: Colors.white,
              filled: true,
              prefixIcon: Icon(Icons.monetization_on_rounded),
              enabledBorder: OutlineInputBorder(
                borderSide: BorderSide(
                  width: 4,
                  color: Color.fromRGBO(181, 134, 63,1),
                ),
                borderRadius: BorderRadius.circular(4),
              ),
              focusedBorder: OutlineInputBorder(
                borderSide: BorderSide(
                  width: 4,
                  color: Color.fromRGBO(181, 134, 63,1),
                ),
                borderRadius: BorderRadius.circular(4),
              ),
            ),
          ),
        ),
        /*ElevatedButton(
          onPressed: () => calcula,
          style: ElevatedButton.styleFrom(
            backgroundColor: Color.fromRGBO(181, 134, 63,1),
            elevation: 5,
          ),
          child: Text(
            "Calcular",
            style: TextStyle(color: Colors.white),
          ),
        ),*/
        Padding(
          padding: const EdgeInsets.all(20),
          child: Text(
              "R\$ ${_resultado.toStringAsFixed(2)}",
              style: TextStyle(
                fontSize: 40,
                fontWeight: FontWeight.bold,
                color: Colors.black,
              )
          ),
        ),
      ],
    );
  }
}



